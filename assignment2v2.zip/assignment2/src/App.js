import React, {useState} from 'react';
import Modal from './components/Modal/Modal';
import Card from './components/Card/Card';
import Input from './components/Input/Input';
import Select from './components/Select/Select';
import TextArea from './components/TextArea/TextArea';
import Button from './components/Button/Button';

function App() {
  // variables to manage content in input element for name
  const [name, setName] = useState('');
  const onChangeName = (e) => {setName(e.target.value)};
  // variables to manage content in input element for email
  const [email, setEmail] = useState('');
  const onChangeEmail = (e) => {setEmail(e.target.value)};
  // variables to manage content in select element
  const [topic, setTopic] = useState('');
  const onTopicChange = (e) => {setTopic(e.target.value)};
  // variables to manage content in textarea element
  const [content, setContent] = useState('');
  const onContentChange = (e) => {setContent(e.target.value)};
  // variables to display submit button or modal
  const [isOpen, setModal] = useState(false);
  const openModal = () => {setModal(true)};
  const closeModal = () => {setModal(false)};

  return (
    <div className="App">
    <Card>
        <form>
          <p>Please fill in this form</p>
          Name <Input type="text" name="name" placeholder="Enter name" onChange={onChangeName} /> <br/>
          Email <Input type="email" name="email" placeholder="Enter email" onChange={onChangeEmail} /> <br/>
          Topics <br/>
          <Select onChange={onTopicChange}>
				    <option value="Hockey">Hockey</option>
				    <option value="Soccer">Soccer</option>
				    <option value="Baseball">Baseball</option>
				    <option value="Other">Other</option>
          </Select> <br/>
          Content <br/>
          <TextArea placeholder="Enter description" onChange={onContentChange} /> <br/>
          { isOpen ? (
            <Modal isOpen={openModal} onClose={closeModal}>
              Name is {name}<br/>
              Email is {email}<br/>
              Topic is {topic}<br/>
              Content is {content}<br/>
            </Modal>
          ) : (
          <Button type="button" handleClick={openModal}>
            Submit
          </Button>
          )}
        </form>
    </Card>
    </div>
  );
}

export default App;
